import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-cyan-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-6">
              <span className="text-white">مدرسة</span>
              <span className="text-amber-400"> الأقصى</span>
            </h3>
            <p className="mb-6 text-gray-300">
              نسعى لتقديم تعليم متميز يساهم في بناء جيل واعي قادر على مواجهة تحديات المستقبل بكفاءة وإبداع.
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <a href="#" className="bg-white bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-all">
                <Facebook size={20} />
              </a>
              <a href="#" className="bg-white bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-all">
                <Twitter size={20} />
              </a>
              <a href="#" className="bg-white bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-all">
                <Instagram size={20} />
              </a>
              <a href="#" className="bg-white bg-opacity-20 p-2 rounded-full hover:bg-opacity-30 transition-all">
                <Youtube size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative">
              روابط سريعة
              <span className="absolute bottom-0 right-0 w-12 h-1 bg-amber-400 mt-2"></span>
            </h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-300 hover:text-white transition-colors">الرئيسية</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-white transition-colors">عن المدرسة</Link>
              </li>
              <li>
                <Link to="/courses" className="text-gray-300 hover:text-white transition-colors">البرامج الدراسية</Link>
              </li>
              <li>
                <Link to="/news" className="text-gray-300 hover:text-white transition-colors">الأخبار والفعاليات</Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-white transition-colors">اتصل بنا</Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative">
              الاتصال بنا
              <span className="absolute bottom-0 right-0 w-12 h-1 bg-amber-400 mt-2"></span>
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="ml-2 mt-1 text-amber-400" />
                <span className="text-gray-300">شارع الأقصى، حي السلام، القدس، فلسطين</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="ml-2 text-amber-400" />
                <span className="text-gray-300">+970 2 123 4567</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="ml-2 text-amber-400" />
                <span className="text-gray-300">info@alaqsaschool.edu.ps</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative">
              ساعات العمل
              <span className="absolute bottom-0 right-0 w-12 h-1 bg-amber-400 mt-2"></span>
            </h3>
            <ul className="space-y-3 text-gray-300">
              <li className="flex justify-between">
                <span>السبت - الخميس:</span>
                <span>7:30 ص - 2:30 م</span>
              </li>
              <li className="flex justify-between">
                <span>الجمعة:</span>
                <span>مغلق</span>
              </li>
              <li className="flex justify-between">
                <span>ساعات الإدارة:</span>
                <span>8:00 ص - 3:00 م</span>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-gray-700 my-8" />

        <div className="text-center text-gray-400">
          <p>جميع الحقوق محفوظة &copy; {new Date().getFullYear()} - مدرسة الأقصى</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;