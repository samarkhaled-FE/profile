import React from 'react';
import PageHeader from './components/PageHeader';
import ContactForm from './components/ContactForm';
import ContactInfo from './components/ContactInfo';
import Map from './components/Map';

const Contact: React.FC = () => {
  return (
    <div>
      <PageHeader />
      
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ContactForm />
            <ContactInfo />
          </div>
        </div>
      </section>
      
      <Map />
    </div>
  );
};

export default Contact;